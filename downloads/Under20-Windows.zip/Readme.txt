Under 20 for Windows 10 and 11 (x64)

Extract the ZIP, open Under20.exe, and drop one or more files into the window.
Clicking the drop zone opens a multi-file picker. Each finished copy goes beside
its source. Select a queue row to cancel, read its exact output size, or open
its location in Explorer.

The limit is 20,000,000 bytes. Smaller inputs are skipped. If a name is taken,
the new copy gets (2), (3), and so on. A copy is published after the app checks
its tracks and timings, decodes its full audio and video, and verifies its size.

Under 20 uses your installed ffmpeg.exe and ffprobe.exe. A standard FFmpeg
build with libx264, AAC and FLAC is recommended.
The app looks on PATH and in common installation folders. If it shows
Locate FFmpeg, select your installed ffmpeg.exe. If ffprobe.exe is in a
separate folder and cannot be found automatically, select it once as well.
Processing runs locally.

Video normally uses H.264 and AAC in MP4. Text subtitles and alternate audio
tracks are kept. Styled/graphic subtitles or embedded attachments can use a
Matroska container to preserve them. Compatible audio/video streams can pass
through without re-encoding when rewrapping alone fits the limit.

Audio uses lossless FLAC first for eligible integer PCM or lossless sources
up to 24 bits. Otherwise it uses AAC in M4A. Enable Keep WAV before dropping
audio-only files to request PCM WAV. WAV may need a lower bit depth or sample
rate to fit. Audio channel count is checked. If a full-length WAV cannot fit
at the supported rates, the queue explains why.

Before reducing video dimensions or removing extra tracks, the app shows the
proposed changes for that file. Choose No to skip it. Covers and container
metadata are outside the share copy's playback checks.

The source folder is optional and is not needed to use the app.

Media checks included an 18-second portrait reel, an MKV with two audio tracks and
subtitles, and 140 seconds of stereo PCM. The default copies kept all 540
video frames, both MKV audio tracks and subtitle cues, and the exact audio
samples in the FLAC output. Keep WAV produced 32 kHz stereo PCM.

The media checks ran against FFmpeg 7.1.5 on Linux using the same C++ engine
as the Windows executable. This build has not been run on a native Windows
desktop.
